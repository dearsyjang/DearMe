<template>
  <div>
    <calendar-comp></calendar-comp>
    
  </div>
</template>

<script>

  import CalendarComp from '@/views/calendar/components/CalendarComp.vue'

  export default {
    name : 'CalendarView',
    components: {CalendarComp},
    
  }
</script>
<style>

</style>

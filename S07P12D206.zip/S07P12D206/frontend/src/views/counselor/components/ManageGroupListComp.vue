<template>
  <div>
    <manage-group-list-item-comp></manage-group-list-item-comp>
  </div>
</template>

<script>
import ManageGroupListItemComp from '@/views/counselor/components/ManageGroupListItemComp.vue'


  export default {
    name : 'ManageGroupListComp',
    components:{ManageGroupListItemComp,
    
      
    }
    
  }

</script>

<style>
</style>
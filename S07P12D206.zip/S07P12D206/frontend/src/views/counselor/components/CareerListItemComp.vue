<template>
  <div>
    <h2>약력1</h2>
  </div>
</template>

<script>
  export default {
    name : 'CareerListItemComp',
    components:{
      
    }
    
  }

</script>

<style>
</style>
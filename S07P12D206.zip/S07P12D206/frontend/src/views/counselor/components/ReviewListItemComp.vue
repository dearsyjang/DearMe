<template>
  <div>
    <h4>리뷰1</h4>
  </div>
</template>

<script>
  export default {
    name : 'ReviewListItemComp',
    components:{
      
    }
    
  }

</script>

<style>
</style>
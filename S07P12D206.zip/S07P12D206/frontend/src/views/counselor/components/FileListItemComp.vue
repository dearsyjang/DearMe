<template>
  <div>
    <h5>파일1</h5>
  </div>
</template>

<script>
  export default {
    name : 'FileListItemComp',
    components:{
      
    }
    
  }

</script>

<style>
</style>
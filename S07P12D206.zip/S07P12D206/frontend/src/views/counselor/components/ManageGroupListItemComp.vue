<template>
  <div>

  </div>
</template>

<script>
  export default {
    name : 'ManageGroupListItemComp',
    components:{
      
    }
    
  }

</script>

<style>
</style>
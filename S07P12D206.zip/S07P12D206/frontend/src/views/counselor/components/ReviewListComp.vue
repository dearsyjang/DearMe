<template>
  <div>
    <review-list-item-comp></review-list-item-comp>
  </div>
</template>

<script>
import ReviewListItemComp from '@/views/counselor/components/ReviewListItemComp.vue'
  export default {
    name : 'ReviewListComp',
    components:{
      ReviewListItemComp
    }
    
  }

</script>

<style>
</style>
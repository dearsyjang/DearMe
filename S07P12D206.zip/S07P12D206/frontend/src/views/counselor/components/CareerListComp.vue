<template>
  <div>
    <career-list-item-comp></career-list-item-comp>
  </div>
</template>

<script>
import CareerListItemComp from '@/views/counselor/components/CareerListItemComp.vue'
  export default {
    name : 'CareerListComp',
    components:{CareerListItemComp
      
    }
    
  }

</script>

<style>
</style>
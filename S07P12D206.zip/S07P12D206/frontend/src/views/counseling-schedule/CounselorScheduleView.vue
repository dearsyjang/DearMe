<template>
  <div>
    <calendar-comp></calendar-comp>
    
  </div>
</template>

<script>

  import calendarComp from '@/views/counseling-schedule/components/calendarComp.vue'

  export default {
    name : 'CounselorScheduleView',
    components: {calendarComp},
    
  }
</script>
<style>

</style>

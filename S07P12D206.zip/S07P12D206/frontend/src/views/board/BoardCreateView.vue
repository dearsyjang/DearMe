<template>
<div>
    <board-form-comp></board-form-comp>
</div>
</template>
<script>
import boardFormComp from './components/boardFormComp.vue'

export default {
  components: { boardFormComp  },
  data(){
    return {
    }
  }

}
</script>

<style>

</style>
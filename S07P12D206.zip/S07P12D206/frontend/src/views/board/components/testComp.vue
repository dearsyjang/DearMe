<template>
  <div>
    {{ comments }}
    </div>

</template>
<script>
export default {
  props: {
    comments: Array
  },
  components: {},
  data() {
    return {
      sampleData: ''
    }
  },
  setup() {},
  created() {},
  mounted() {},
  unmounted() {},
  methods: {}
}
</script>

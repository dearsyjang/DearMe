import VideoDiaryCreateView from '@/views/video-diary/VideoDiaryCreateView.vue'

export default [
  {
    path: '/videodiary',
    name: 'videodiary',
    component: VideoDiaryCreateView
  }]
import PointView from "@/views/point/PointView.vue";

export default [
  {
    path: "/point",
    name: "PointView",
    component: PointView,
  },
];